# Shopping-Cart-Project
A personal project using NodeJS / Express / JQuery / Bootstrap / MongoDB

It is based on the online youtube videos from Academind, with edits to allow for compatibility of the updated java packages.
